// Copyright 1998-2019 Epic Games, Inc. All Rights Reserved.

#include "Homework4.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, Homework4, "Homework4" );
 